Hi,
Thank you for installing this software
Please do note this is a BETA and I am not responsible for anything that happens as a result of installing this
HOW TO USE THIS PACKAGE:
No, there is not an app
in terminal, use pam_py_usb_add to add a device
Must be mounted in /Volumes/ first
use pam_py_usb_renew to invalidate all old keys
and pam_py_usb_check (no root) to confirm it is working